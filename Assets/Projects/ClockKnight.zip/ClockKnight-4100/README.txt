Emanuel Sweeney
Daniel Onyema

Materials Needed: None (assuming your computer runs on Windows and therefore can run .exe)

Project Work Strengths
Variety in enemy types
Additional skills for player character, including power ups
Complete visual overhaul from base project


Project Work Weaknesses
- Lacking in chunk and enemy variety
- Due to Procjam crunch, were unable to make all of the power-ups, enemies, and platforming hazards 

Project Team Strengths
- Communication
- Quick to adapt to sprite-making Gamemaker

Project Team Weaknesses
- Procrastination – tended to work in bursts as the due dates approached rather than consistently.


Plans moving forward
- Continue with the project and maybe finish it, expanding on variety in hazards, chunks, enemies, and power-ups.
- Remove underlying MarioPCG code so we have a 'cleaner' game engine.
- Maybe even a boss or two at the end of some levels.